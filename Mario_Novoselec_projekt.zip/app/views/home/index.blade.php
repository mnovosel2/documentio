@extends('default.layout')
@section('content')
        <header>
        </header>
        <div class="wrapper">
        </div>
         @include('includes.scripts')
    </body>
@stop