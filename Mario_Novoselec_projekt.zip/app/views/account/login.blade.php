<html>
    <head>


    </head>
    <body>

        <h2>Login form</h2>

        <form action="/api/account/login" method="POST">

            <input type="text" name="email" placeholder="Email..." id="email"/>

            <input type="password" name="password" placeholder="Password..." id="password"/>

            <input type="submit" id="sbn-btn"/>

        </form>


    </body>
</html>