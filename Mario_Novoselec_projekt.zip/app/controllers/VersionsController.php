<?php

class VersionsController extends BaseController {

	/**
	 * Version Repository
	 *
	 * @var Version
	 */
	protected $version;

	public function __construct(Version $version)
	{
		$this->version = $version;
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		$versions = $this->version->all();

		return View::make('versions.index', compact('versions'));
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('versions.create');
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$input = Input::all();
		$validation = Validator::make($input, Version::$rules);

		if ($validation->passes())
		{
			$this->version->create($input);

			return Redirect::route('versions.index');
		}

		return Redirect::route('versions.create')
			->withInput()
			->withErrors($validation)
			->with('message', 'There were validation errors.');
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$version = $this->version->findOrFail($id);

		return View::make('versions.show', compact('version'));
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$version = $this->version->find($id);

		if (is_null($version))
		{
			return Redirect::route('versions.index');
		}

		return View::make('versions.edit', compact('version'));
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$input = array_except(Input::all(), '_method');
		$validation = Validator::make($input, Version::$rules);

		if ($validation->passes())
		{
			$version = $this->version->find($id);
			$version->update($input);

			return Redirect::route('versions.show', $id);
		}

		return Redirect::route('versions.edit', $id)
			->withInput()
			->withErrors($validation)
			->with('message', 'There were validation errors.');
	}

	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		$this->version->find($id)->delete();

		return Redirect::route('versions.index');
	}

}
